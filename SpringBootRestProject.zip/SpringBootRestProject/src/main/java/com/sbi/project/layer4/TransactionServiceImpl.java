package com.sbi.project.layer4;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.SpendAnalysis;
import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.ApplicantRepository;
import com.sbi.project.layer3.TransactionRepository;
@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository tx;	
	
	

	@Override
	public void createTxn(Transaction txn) {
		// TODO Auto-generated method stub
		tx.addTransaction(txn);
	}

	@Override
	public List<Transaction> getAlltxn() {
		// TODO Auto-generated method stub
		return tx.findAllTxns();
	}

	@Override
	public Transaction getTxn(int no) {
		// TODO Auto-generated method stub
		return tx.findTrans(no);
	}
	
	public List<Transaction> getAllTxnsofAcc(int accNo){
		return tx.getAllTxnsofAccRepo(accNo);
		
	}

	@Override
	public SpendAnalysis getSpendAnalysisService(String mnthYear, int appid) {
		// TODO Auto-generated method stub
		return tx.getSpendAnalysis(mnthYear, appid);
	}

}
