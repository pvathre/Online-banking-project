package com.sbi.project.layer3;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Login;
import com.sbi.project.layer2.Transaction;
@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class LoginRepositoryImpl extends BaseRepositoryImpl implements LoginRepository {
	@Autowired
	ApplicantRepository apprepo;
			@Override
	public Applicant findLogin(String userName, String password) {
		// TODO Auto-generated method stub
				Login newlogin = new Login();	
				try {
			
		TypedQuery<Login> query = entityManager.createQuery("from Login l where "
						+ "l.userName=:x AND l.password=:y", Login.class);
		query.setParameter("x", userName);
		query.setParameter("y", password);
		newlogin =query.getSingleResult();
		}catch(NoResultException e) {
					return null;
				}
		Applicant app = apprepo.findApp(newlogin.getUserId());
		return app;
				
	}
}
