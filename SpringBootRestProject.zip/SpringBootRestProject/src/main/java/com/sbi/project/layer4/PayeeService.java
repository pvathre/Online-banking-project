package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Payee;

@Service
public interface PayeeService {

	public void createP(Payee pa);
	public void modifyP(Payee pa);
	public void removeP(int pa);
	public void findP(int pa);
	public List<Payee> findAllP();
	public List<Payee> getPayeeForApplicantService(int appid);

}
