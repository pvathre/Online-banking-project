package com.sbi.project.layer2;

public class SpendAnalysis {
	
	private float totWithdraw;
	
	private float totTransfer;
	
	private float totCredit;
	
	private float totFDCredit;
	
	private float TotalTxnAmt;

	public float getTotWithdraw() {
		return totWithdraw;
	}

	public void setTotWithdraw(float totWithdraw) {
		this.totWithdraw = totWithdraw;
	}

	public float getTotTransfer() {
		return totTransfer;
	}

	public void setTotTransfer(float totTransfer) {
		this.totTransfer = totTransfer;
	}

	public float getTotCredit() {
		return totCredit;
	}

	public void setTotCredit(float totCredit) {
		this.totCredit = totCredit;
	}

	public float getTotFDCredit() {
		return totFDCredit;
	}

	public void setTotFDCredit(float totFDCredit) {
		this.totFDCredit = totFDCredit;
	}

	public float getTotalTxnAmt() {
		return TotalTxnAmt;
	}

	public void setTotalTxnAmt(float totalTxnAmt) {
		TotalTxnAmt = totalTxnAmt;
	}1
	
	

}
