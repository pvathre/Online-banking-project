package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;

@Service
public interface ApplicationService {

	
		String createApplicationService(Applicant app);
		List<Applicant> getAllApplicants();
		String updateAppliService(Applicant app);
		String removeAppliService(int applino);	
		Applicant getAppliService(int applino);
		Applicant authenticate(String userName,String password);
		
	
}
