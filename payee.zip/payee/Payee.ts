export class Payee{
payeeid:number=0;
payeename:string="";
payeeacc:string="";
payeeifsc:string="";
}
