package com.sbi.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;


import com.sbi.layer2.Applicant;
@Repository
public interface ApplicantRepository {
	void createApp(Applicant app);
	void modifyApp(Applicant app);
	void removeApp(int apno);
	Applicant findApp(int apno);
	List<Applicant> findAllApp();
	
	
}
