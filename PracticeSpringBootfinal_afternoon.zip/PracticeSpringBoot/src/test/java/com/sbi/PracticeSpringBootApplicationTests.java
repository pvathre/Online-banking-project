package com.sbi;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.layer2.Account;
import com.sbi.layer2.Payee;
import com.sbi.layer3.AccountRepository;
import com.sbi.layer3.PayeeRepository;


@SpringBootTest
class PracticeSpringBootApplicationTests {
@Autowired
AccountRepository appRepo;

@Autowired
PayeeRepository pa;

	@Test
	void contextLoads() {
		
		
	}

	@Test
	void getAccount()
	{
	
	List<Account> all = appRepo.findAllAccounts();
	System.out.println("all applicant size "+all.size());
	for (Account acc : all)
	{
		System.out.println("Account num        : "+acc.getAccountNumber());
		System.out.println("name     :  "+acc.getAccountHolderName());
		System.out.println("balance     :  "+acc.getAccountBalnce());
		
	}
	}
	@Test
	void getA()
	{
	
	List<Payee> all = pa.findAllP();
	System.out.println("all applicant size "+all.size());
	for (Payee pa : all)
	{
		System.out.println("payee acc        : "+pa.getPayeeacc());
		System.out.println("id     :  "+pa.getPayeeid());
		System.out.println("ifsc     :  "+pa.getPayeeifsc());
		System.out.println(" name    :  "+pa.getPayeename());
		
		
	}
	
	
	
}

}
