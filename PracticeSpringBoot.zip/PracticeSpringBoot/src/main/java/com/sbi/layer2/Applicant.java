package com.sbi.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_table_new")
public class Applicant {

	
	
	
	@Id
	
	@Column(name="applicant_id")
	private int applicantid;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_mobile")
	private String mobileNumb;
	

	
	@Column(name="applicant_father")
	private String applicantFatherName;
	
	@Column(name="applicant_mother")
	private String applicantMotherName;
	
	
	@Column(name="applicant_married")
	private String married;
	
		
	@Column(name="applicant_aadhar")
	private String aadhar;
	
	@Column(name="applicant_panCard")
	private String panCard;
	
	@Column(name="applicant_photo")
	private String photo;
	
	@Column(name="applicant_status")
	private String applicant_status;
	
	@Column(name="account_type")
	private String account_type;
	

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	public String getApplicant_status() {
		return applicant_status;
	}

	public void setApplicant_status(String applicant_status) {
		this.applicant_status = applicant_status;
	}

	public int getApplicantid() {
		return applicantid;
	}

	public void setApplicantid(int applicantid) {
		this.applicantid = applicantid;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getMobileNumb() {
		return mobileNumb;
	}

	public void setMobileNumb(String mobileNumb) {
		this.mobileNumb = mobileNumb;
	}



	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	public String getApplicantMotherName() {
		return applicantMotherName;
	}

	public void setApplicantMotherName(String applicantMotherName) {
		this.applicantMotherName = applicantMotherName;
	}
/*
	public LocalDate getApplicantBirthDate() {
		return applicantBirthDate;
	}

	public void setApplicantBirthDate(LocalDate applicantBirthDate) {
		this.applicantBirthDate = applicantBirthDate;
	}
*/
	

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	
	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	
}
