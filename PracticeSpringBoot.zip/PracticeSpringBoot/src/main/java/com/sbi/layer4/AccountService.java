package com.sbi.layer4;

import java.util.List;

import com.sbi.layer2.Account;
import com.sbi.layer2.Applicant;

public interface AccountService {

	public void createAccSer(Account a);
	public List<Account> getAll();
	public void getAcc(int no);
	public void updAccSer(Account a);
	public void rem(int no);
	
}
