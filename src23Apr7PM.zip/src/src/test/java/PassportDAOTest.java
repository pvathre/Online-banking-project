import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.PassportDAOImpl;
import entity.Passport;
public class PassportDAOTest {

	PassportDAOImpl passTest	= new PassportDAOImpl();
	
	@Test
	public void createPassportTest() {
		Passport newpass = new Passport();
		newpass.setPassportNumber("DBC45JN");
		newpass.setIssueDate(LocalDate.of(2020, 8, 10));
		newpass.setExpiryDate(LocalDate.of(2030, 8, 10));
		newpass.setIssuedBy("Govt of India");
		passTest.createPassport(newpass);
		System.out.println("Added Passport Successfully");
		
	}
	
	@Test
	public void selectPassTest() {
		Passport selPass = passTest.selectPass("ABC45HN");
		
		
	}
	
	@Test
	public void updatePassTest() {
		Passport selPass = passTest.selectPass("ABC45HN");
		Assertions.assertTrue(selPass!=null);
		selPass.setIssueDate(LocalDate.of(2021, 8, 10));
		selPass.setExpiryDate(LocalDate.of(2031, 8, 10));
		selPass.setIssuedBy("Govt of USA");
		passTest.updatePass(selPass);
		System.out.println("Updated Passport Successfully");

	}
	
	@Test
	public void deletePassTest() {
		passTest.deletePass("ABC45HN");
	}
	
	@Test
	public void selectAllPassportsTest() {
		passTest.selectAllPassports();
	}

	
}
