import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Customer;
import entity.Subscription;

public class ManyToManyCustSubs {
	EntityManagerFactory emf;
	EntityManager em ;
	
	public ManyToManyCustSubs() {
		
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();
		
	}
	
	@Test
	public void createCustomers() {
		Customer cust1 = new Customer();
		cust1.setCustName("Ram");
		cust1.setCustEmail("ram@gmail.com");
		
		Customer cust2 = new Customer();
		cust2.setCustName("Reghu");
		cust2.setCustEmail("reghu@gmail.com");
		
		Customer cust3 = new Customer();
		cust3.setCustName("Shan");
		cust3.setCustEmail("shan@gmail.com");
		
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(cust1);
			em.persist(cust2);
			em.persist(cust3);
		et.commit();	
		
	}

	@Test
	public void createSubscriptions() {
		Subscription sub1 = new Subscription();
		sub1.setSubs_name("Classic");
		sub1.setSubs_type("monthly");
		
		Subscription sub2 = new Subscription();
		sub2.setSubs_name("Platinum");
		sub2.setSubs_type("6 month");
		
		Subscription sub3 = new Subscription();
		sub1.setSubs_name("VIP");
		sub1.setSubs_type("1 year");
		
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(sub1);
			em.persist(sub2);
			em.persist(sub3);
		et.commit();	
		
	}
	
	
	@Test
	public void asssignSubscriptionToExCust() {
		Customer cust = em.find(Customer.class, 3);
		
		Subscription sub1 = em.find(Subscription.class, 4);
		Subscription sub2 = em.find(Subscription.class, 5);
		Subscription sub3 = em.find(Subscription.class, 6);
		
		cust.getSubsList().add(sub1);
		cust.getSubsList().add(sub2);
		cust.getSubsList().add(sub3);
		
		EntityTransaction et = em.getTransaction();
		
		et.begin();
			em.merge(cust);
		et.commit();
		
	}
	
	@Test
	public void getSubscriptionOfCust() {
		
		Customer cust = em.find(Customer.class, 3);
		
		Set<Subscription> subsList = cust.getSubsList();
		
		for(Subscription currsub : subsList ) {
			System.out.println("Name	: "+currsub.getSubs_name());
		}
		
	}
	
	
	
}
