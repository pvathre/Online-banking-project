import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.ProjectDAOImpl;
import entity.Project;
public class ProjectDAOTest {

	ProjectDAOImpl projTest	= new ProjectDAOImpl();
	
	@Test
	public void createProjectTest() {
		Project newproj = new Project();
		newproj.setProjectTitle("Online Banking ");
		newproj.setProjectDeadLine(LocalDate.of(2025, 10, 16));
		projTest.createProject(newproj);
		System.out.println("Added Project Successfully");
		
	}
	
	@Test
	public void selectProjTest() {
		Project selProj = projTest.selectProj(1);
		
		
	}
	
	@Test
	public void updateProjTest() {
		Project selProj = projTest.selectProj(1);
		Assertions.assertTrue(selProj!=null);
		selProj.setProjectDeadLine(LocalDate.of(2023, 8, 10));
		projTest.updateProj(selProj);
		System.out.println("Updated Project Successfully");

	}
	
	@Test
	public void deleteProjTest() {
		projTest.deleteProj(1);
	}
	
	@Test
	public void selectAllProjectsTest() {
		projTest.selectAllProjects();
	}

	
}
