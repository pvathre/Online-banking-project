package dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Project;



public class ProjectDAOImpl implements ProjectDAO{
	
	EntityManagerFactory 	emf;
	EntityManager 			em ;		
	EntityTransaction 		et;
	
	 public ProjectDAOImpl() {
		this.emf 	= Persistence.createEntityManagerFactory("MyJPA");
		this.em 	= emf.createEntityManager();		
		this.et 	= em.getTransaction();
			
	}
	public void createProject(Project newproj) {		
		et.begin();
		 em.persist(newproj);
		et.commit();		
		
	}

	public Project selectProj(int projId) {
		
		Project selProj = em.find(Project.class, projId); //2 is primary key 
		try {
				System.out.println(" Project No		    :"+selProj.getProjectId());
				System.out.println(" Project Title		:"+selProj.getProjectTitle());
				System.out.println(" Project dead line	:"+selProj.getProjectDeadLine());
				
					
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		return selProj;
	}

	public void updateProj(Project newproj) {
		
		et.begin();
		 em.merge(newproj);
		et.commit();
		
	}

	public void deleteProj(int projId) {
		Project selProj = em.find(Project.class, projId); //2 is primary key 
		try {			
			System.out.println(" Project No		    :"+selProj.getProjectId());
			System.out.println(" Project Title		:"+selProj.getProjectTitle());
			System.out.println(" Project dead line	:"+selProj.getProjectDeadLine());
		
			et.begin();
				em.remove(selProj);
			et.commit();
			
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		
		
		
	}

	public void selectAllProjects() {
		Query query 			= em.createQuery("from Project");
		List<Project> projList	= query.getResultList();
		if(projList.size()>0) {
			for(Project   currProj : projList){
				System.out.println(" Project No		    :"+currProj.getProjectId());
				System.out.println(" Project Title		:"+currProj.getProjectTitle());
				System.out.println(" Project dead line	:"+currProj.getProjectDeadLine());
			System.out.println("====================================");
				
			}
		}
		
	}
	

}
