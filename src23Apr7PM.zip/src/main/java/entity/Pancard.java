package entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="pancard")
public class Pancard {
	
	@Id
	@GeneratedValue
	@Column(name="pan_no")
	private String panNo;
	
	@Column(name="pan_name")
	private String name;
	
	@Column(name="pan_fname")
	private String fatherName;
	
	@Column(name="pan_dob")
	private LocalDate dob;
	
	@OneToOne
	@JoinColumn(name="pan_empId")
	private Employee panEmpl;

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Employee getPanEmpl() {
		return panEmpl;
	}

	public void setPanEmpl(Employee panEmpl) {
		this.panEmpl = panEmpl;
	} 
	
	
}
