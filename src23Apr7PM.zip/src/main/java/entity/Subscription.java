package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="subs_tbl")
public class Subscription {
	
	@Id
	@GeneratedValue
	@Column(name="subs_id")
	private int subsId;
	
	@Column(name="subs_name")
	private String subs_name;
	
	@Column(name="subs_type")
	private String subs_type;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade= CascadeType.ALL)
	@JoinTable(name="cust_subs_Link",
	joinColumns = {@JoinColumn(name="sid")},
	inverseJoinColumns= {@JoinColumn(name="cid")})
	private Set<Customer> custList = new HashSet<Customer>();

	
	
	public int getSubsId() {
		return subsId;
	}

	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}

	public String getSubs_name() {
		return subs_name;
	}

	public void setSubs_name(String subs_name) {
		this.subs_name = subs_name;
	}

	public String getSubs_type() {
		return subs_type;
	}

	public void setSubs_type(String subs_type) {
		this.subs_type = subs_type;
	}

	public Set<Customer> getCustList() {
		return custList;
	}

	public void setCustList(Set<Customer> custList) {
		this.custList = custList;
	}
	
	
}
