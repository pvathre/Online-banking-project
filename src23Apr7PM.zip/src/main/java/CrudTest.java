import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import dao.EmployeeDAOImpl;
import entity.Employee;

public class CrudTest {
	public static void main(String[] args) {
		/*System.out.println("Trying to read persistence.xml...");
		
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("MyJPA");
		EntityManager em = emf.createEntityManager();		
		EntityTransaction et = em.getTransaction();
		
		
		Employee emp = new Employee();
		emp.setEmployeeNumber(103);
		emp.setName("Jacky");
		emp.setJob("Manager");
		emp.setJoiningDate(LocalDate.of(2020, 10, 20));
		emp.setSalary(70000);
		
		
		
		
		et.begin();
			em.persist(emp);
		et.commit();
		*/
		EmployeeDAOImpl  empDAOImp = new EmployeeDAOImpl();
		
		Employee newemp = new Employee();
		newemp.setAge(36);
		newemp.setJob("Analyst");
		newemp.setJoiningDate(LocalDate.of(2021, 10, 8));
		newemp.setName("Ramachandr");
		newemp.setSalary(65000);
		
		empDAOImp.createEmp(newemp);
		
		Employee updateemp = new Employee();
		
		updateemp = empDAOImp.selectEmp(5);
		
		updateemp.setJob("Sr Analyst");		
		updateemp.setSalary(95000);
		
		
		empDAOImp.updateEmp(updateemp);
		
		empDAOImp.deleteEmp(2);
		
	}
}
