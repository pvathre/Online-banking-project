package com.sbi.project.layer4;

import java.util.List;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Transaction;

public interface TransactionService {

	public void createTxn(Transaction txn);
	public List<Transaction> getAlltxn();
	public Transaction getTxn(int no);
	public List<Transaction> getAllTxnsofAcc(int accNo);
	
	
	
}
