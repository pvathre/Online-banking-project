package com.sbi.project.layer3;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Payee;

@Repository
public class PayeeRepositoryImpl  extends BaseRepositoryImpl implements PayeeRepository{

	@Transactional
	@Override
	public void createP(Payee pa) {
		// TODO Auto-generated method stub
		super.persist(pa);
	}

	@Transactional
	@Override
	public void modifyP(Payee pa) {
		// TODO Auto-generated method stub
		super.merge(pa);
	}

	@Transactional
	@Override
	public void removeP(int pa) {
		// TODO Auto-generated method stub
		Payee a=super.find(Payee.class,pa);
		super.remove(a);
	}

	@Transactional
	@Override
	public Payee findP(int pa) {
		// TODO Auto-generated method stub
		return super.find(Payee.class,pa);
		
	}

	@Transactional
	@Override
	public List<Payee> findAllP() {
		// TODO Auto-generated method stub
		return super.findAll("Payee");
	}

	
	public List<Payee> getPayeeForApplicantRepo(int appId) {
		//String token="allPayeeOfApplicant";
		TypedQuery<Payee> query = entityManager.createQuery("from Payee p where p.appid.applicantid=:x", Payee.class);
		query.setParameter("x", appId);
		
		
		List<Payee> payee = query.getResultList();
		// TODO Auto-generated method stub
		return payee;
	}
	
	
}
