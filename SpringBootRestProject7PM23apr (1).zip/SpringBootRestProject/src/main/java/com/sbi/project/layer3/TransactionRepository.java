package com.sbi.project.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Transaction;
@Repository
public interface TransactionRepository {
	void addTransaction(Transaction txn );
	Transaction findTrans(int txnId);
	List<Transaction> findAllTxns();
	List<Transaction> getAllTxnsofAccRepo(int accNo);
}
