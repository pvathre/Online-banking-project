package com.sbi.project.layer3;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Payee;
import com.sbi.project.layer2.Transaction;
@Repository
public class TransactionRepositoryImpl extends BaseRepositoryImpl implements TransactionRepository {
		
	@Transactional
	public void addTransaction(Transaction txn) {
		super.persist(txn);
		// TODO Auto-generated method stub
		
	}
	@Override
	public Transaction findTrans(int txnId) {
		// TODO Auto-generated method stub
		return super.find(Transaction.class, txnId);
	}
	@Override
	public List<Transaction> findAllTxns() {
		// TODO Auto-generated method stub
		return super.findAll("Transaction");
	}
	public List<Transaction> getAllTxnsofAccRepo(int accNo){
		
		TypedQuery<Transaction> query = entityManager.createQuery("from Transaction p where "
				+ "p.txnFromAcc.accountNumber=:x ORDER BY p.txnDate  DESC", Transaction.class).setMaxResults(10);
		query.setParameter("x", accNo);
		
		
		List<Transaction> payee = query.getResultList();
		// TODO Auto-generated method stub
		return payee;
		
	}
}
