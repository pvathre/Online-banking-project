import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Applicant } from './applicant-new/Applicant';

@Injectable({
  providedIn: 'root'
})
export class ApplicantService {

  constructor(private myhttp:HttpClient) { }

  fetch():Observable<Applicant>
{return this.myhttp.get<Applicant>("http://localhost:8080/applicants/get/101");

}

fetchall():Observable<Applicant[]>
{return this.myhttp.get<Applicant[]>("http://localhost:8080/applicants/");

}


}
