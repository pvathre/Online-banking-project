import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-applogin',
  templateUrl: './applogin.component.html',
  styleUrls: ['./applogin.component.css']
})
export class ApploginComponent implements OnInit {
username:string="";
password:string="";

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

loginfun()
{this.router.navigate(['/dashboard'])

}

}
