import { Component, OnInit } from '@angular/core';
import { Applicant } from '../applicant-new/Applicant';
import { PayeeService } from '../payee.service';
import { Payee } from '../payee/Payee';

@Component({
  selector: 'app-addpayee',
  templateUrl: './addpayee.component.html',
  styleUrls: ['./addpayee.component.css']
})
export class AddpayeeComponent implements OnInit {

appid:Applicant=new Applicant();  
payeename:string="";
payeeacc:string="";
payeeifsc:string="";
pobj:Payee=new Payee();
data:any;

  constructor(private payS:PayeeService) { }

  ngOnInit(): void {
  }
  msg:any="";
add()
{
  this.appid=this.getLogedApplicant();

 // this.payS.addP(this.pobj).subscribe(
    (data:any) => {
      this.msg = data;
      console.log(data);
      console.log(this.msg);
    }


}

getLogedApplicant():Applicant{
    
  this.data = sessionStorage.getItem("appObj");
  const appObj=this.data;
  return appObj;

}


}
