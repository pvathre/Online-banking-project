import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-top-menu',
  templateUrl: './user-top-menu.component.html',
  styleUrls: ['./user-top-menu.component.css']
})
export class UserTopMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
