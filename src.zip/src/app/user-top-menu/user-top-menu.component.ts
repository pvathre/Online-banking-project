import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-user-top-menu',
  templateUrl: './user-top-menu.component.html',
  styleUrls: ['./user-top-menu.component.css']
})
export class UserTopMenuComponent implements OnInit {
 userName:any;
  constructor(private authObj:AuthenticationService) {
    this.userName=sessionStorage.getItem("userName");
   }

  ngOnInit(): void {
  }

  logout(){
    this.authObj.makeLogout();
  }
}
