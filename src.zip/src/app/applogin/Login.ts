export class Login{
    userName:string ="";
	
	password:string ="";
	
	userType:string ="";
	
	userId:string="";
}
