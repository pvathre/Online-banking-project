import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  

  data :any;
  nouser=false;
  usertype:string='';

  ngOnInit(): void {
    //this.user=true;
   
    this.data = sessionStorage.getItem("userType");
    this.usertype=JSON.stringify(this.data);
    this.showMenu();

  }
  
  showMenu(){
    
    if(this.usertype=='"admin"'){
      
            
    }else if(this.usertype=='"user"'){
      
    }else{
      
      this.nouser =true;
    }
    
  }
  
}
