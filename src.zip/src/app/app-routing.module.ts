import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FAQComponent } from './faq/faq.component';
import { InterestcalComponent } from './interestcal/interestcal.component';

const routes: Routes = [
{path:'faq', component:FAQComponent},
{path:'interest', component:InterestcalComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
