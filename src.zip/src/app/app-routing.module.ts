import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { FAQComponent } from './faq/faq.component';
import { InterestcalComponent } from './interestcal/interestcal.component';

const routes: Routes = [
{path:'faq', component:FAQComponent},
{path:'interest', component:InterestcalComponent},
{path:'aboutus', component:AboutusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
