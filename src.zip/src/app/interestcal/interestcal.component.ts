import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interestcal',
  templateUrl: './interestcal.component.html',
  styleUrls: ['./interestcal.component.css']
})
export class InterestcalComponent implements OnInit {
temp:number=0;
  output:number=0;
  invest:number=0;
  month:number=0;
  
  constructor() { }

  ngOnInit(): void {
  }

cal()
{
this.temp=(this.invest*0.05);
this.temp= this.temp/12;
this.temp=this.temp*this.month;


this.output=Number(this.temp)+Number(this.invest);


}



}


