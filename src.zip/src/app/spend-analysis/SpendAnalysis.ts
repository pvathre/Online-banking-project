export class SpendAnalysis{
    totWithdraw: number =0;
    totTransfer: number =0;
    totCredit: number =0;
    totFDCredit:number =0;
    totalTxnAmt:number=0;
}