import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { SpendAnalysisService } from '../spend-analysis.service';
import { SpendAnalysis } from './SpendAnalysis';

@Component({
  selector: 'app-spend-analysis',
  templateUrl: './spend-analysis.component.html',
  styleUrls: ['./spend-analysis.component.css']
})
export class SpendAnalysisComponent implements OnInit {

  constructor(private spObj:SpendAnalysisService) { 

    this.getSpendDet();
    
  }
  spend:SpendAnalysis=new SpendAnalysis();
  currentMonth:string='March 2022';

  ngOnInit(): void {
   
   
  }
  

  
  highcharts = Highcharts;
  chartOptions:any;
  prepare(){
   this.chartOptions = {   
      series : [{
         type: 'pie' as any,
         name: 'Analysis for '+this.currentMonth,
         data: [
            ['Withdrawal',   this.spend.totWithdraw],
            
            {
               name: 'Credits',
               y: this.spend.totCredit,
               sliced: true,
               selected: true
            },
            ['Transfer',    this.spend.totTransfer],
            ['Savings',     this.spend.totFDCredit]
         ]
      }],
      chart : {
          plotBorderWidth: null as any,
         plotShadow: false
      },
      title : {
         text: 'Spend Analysis for '+this.currentMonth   
      },
      tooltip : {
         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions : {
         pie: {
            allowPointSelect: true,
            cursor: 'pointer',
      
            dataLabels: {
               enabled: false           
            },
      
            showInLegend: true
         }
      }
     
   };

  }
   getSpendDet()
  {
    this.spObj.fetchSpendAnalysis().subscribe(
      (data:SpendAnalysis)=>
      {this.spend=data;
        console.log(this.spend);
        this.prepare();
      
      }
    );
   
    
  }
  prepareChart(){


  }
   
}
