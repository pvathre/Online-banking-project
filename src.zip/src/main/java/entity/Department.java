package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="dept_tbl")
public class Department {
	@Id
	@Column(name="dept_id")
	@GeneratedValue
	private int deptId;
	
	@Column(name="dept_name")
	private String deptName;
	
	@Column(name="dept_loc")
	private String deptLocation;
	
	//Department have many employees
	@OneToMany(mappedBy="deptNo",cascade = CascadeType.ALL)
	Set<Employee> staffList = new HashSet<Employee>();

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		return deptLocation;
	}

	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	public Set<Employee> getStaffList() {
		return staffList;
	}

	public void setStaffList(Set<Employee> staffList) {
		this.staffList = staffList;
	}
	

}
