package entity;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="emp_tbl")
public class Employee {
	
	@Id
	@GeneratedValue
	@Column(name="emp_no")
	private int employeeNumber;
	
	@Column(name="emp_name", length = 20)
	private String name;
	
	@Column(name="emp_job", length =20)
	private String job;
	
	@Column(name="emp_doj")
	private LocalDate joiningDate;
	
	@Column(name="emp_salary")
	private double salary;
	
	@Column (name="emp_age")
	private int age;
	
	 
	@OneToOne(cascade = CascadeType.ALL) 
	@JoinColumn(name="emp_passid")
	private Passport passport;
	
	//many employee have one dept
	@ManyToOne
	@JoinColumn(name="emp_deptno")	
	private Department deptNo;
	
	@OneToOne
	@JoinColumn(name="emp_pan")
	private Pancard empPan;
	
	@OneToMany
	@JoinColumn(name="emp_add")
	private Set<Address> empaddresses = new HashSet<Address>();
	
	@ManyToMany(fetch = FetchType.EAGER, cascade= CascadeType.ALL)
	@JoinTable(name="project_employee_tbl",
	joinColumns={@JoinColumn(name="empId")},
	inverseJoinColumns={@JoinColumn(name="projId")})
	private Set<Project> projectList = new HashSet<Project>();
	
	
	
	public Department getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(Department deptNo) {
		this.deptNo = deptNo;
	}
	public Pancard getEmpPan() {
		return empPan;
	}
	public void setEmpPan(Pancard empPan) {
		this.empPan = empPan;
	}
	public Set<Address> getEmpaddresses() {
		return empaddresses;
	}
	public void setEmpaddresses(Set<Address> empaddresses) {
		this.empaddresses = empaddresses;
	}
	public Set<Project> getProjectList() {
		return projectList;
	}
	public void setProjectList(Set<Project> projectList) {
		this.projectList = projectList;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Passport getPass_id() {
		return passport;
	}
	public void setPass_id(Passport pass_id) {
		this.passport = passport;
	}
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public Department getDept_no() {
		return deptNo;
	}
	public void setDept_no(Department dept_no) {
		this.deptNo = dept_no;
	}
	
	
}
