package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="cust_tbl")
public class Customer {
	
	@Id
	@GeneratedValue
	@Column(name="cust_id")
	private int custId;
	
	@Column(name="cust_name")
	private String custName;
	
	@Column(name="cust_email")
	private String custEmail;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade= CascadeType.ALL)
	@JoinTable(name="cust_subs_Link",
	joinColumns = {@JoinColumn(name="cid")},
	inverseJoinColumns= {@JoinColumn(name="sid")})
	Set<Subscription> subsList = new HashSet<Subscription>();
	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public Set<Subscription> getSubsList() {
		return subsList;
	}

	public void setSubsList(Set<Subscription> subsList) {
		this.subsList = subsList;
	}
	
	
}
