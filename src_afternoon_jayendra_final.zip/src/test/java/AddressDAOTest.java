import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.AddressDAOImpl;
import entity.Address;

public class AddressDAOTest {

	AddressDAOImpl addTest = new AddressDAOImpl();

	@Test
	public void createAddressTest() {
		Address newadd = new Address();
		newadd.setArea("Nerul");
		newadd.setStreet("Sector 40");
		newadd.setCity("navi Mumbai");
		newadd.setCountry("India");
		newadd.setState("Maharashtra");
		newadd.setPin(400706);
		addTest.createAddress(newadd);
		System.out.println("Added Address Successfully");

	}

	@Test
	public void selectAddressTest() {
		Address selAdd = addTest.selectAddress(1);

	}

	@Test
	public void updateAddressTest() {
		Address selAdd = addTest.selectAddress(12);
		Assertions.assertTrue(selAdd != null);
		selAdd.setCity("Thane");
		selAdd.setArea("Panvel");
		addTest.updateAddress(selAdd);
		System.out.println("Updated Address Successfully");

	}

	@Test
	public void deleteaddTest() {
		addTest.deleteAddress("ABC45HN");
	}

	@Test
	public void selectAllAddresssTest() {
		addTest.selectAllAddresses();
	}

}
