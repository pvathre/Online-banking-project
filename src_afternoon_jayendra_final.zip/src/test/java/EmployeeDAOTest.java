
import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.EmployeeDAOImpl;
import entity.Employee;
public class EmployeeDAOTest {

	EmployeeDAOImpl empTest	= new EmployeeDAOImpl();
	
	@Test
	public void createEmployeeTest() {
		Employee newemp = new Employee();
		newemp.setName("Nimya");
		newemp.setAge(35);
		newemp.setJob("TO Sys");
		newemp.setJoiningDate(LocalDate.of(2020, 10, 20));
		newemp.setSalary(50000);
		empTest.createEmp(newemp);
		System.out.println("Added Employee Successfully");
		
	}
	
	@Test
	public void selectEmpTest() {
		Employee selEmp = empTest.selectEmp(1);
		
		
	}
	
	@Test
	public void updateEmpTest() {
		Employee selEmp = empTest.selectEmp(1);
		Assertions.assertTrue(selEmp!=null);
		selEmp.setJob("System Officer");
		selEmp.setSalary(80000);		
		empTest.updateEmp(selEmp);
		System.out.println("Updated Employee Successfully");

	}
	
	@Test
	public void deleteEmpTest() {
		empTest.deleteEmp(1);
	}
	
	@Test
	public void selectAllEmployeesTest() {
		empTest.selectAllEmployees();
	}

	
}
