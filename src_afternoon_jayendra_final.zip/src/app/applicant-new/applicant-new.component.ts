import { Component, OnInit } from '@angular/core';
import { ApplicantService } from '../applicant.service';
import { Applicant } from './Applicant';

@Component({
  selector: 'app-applicant-new',
  templateUrl: './applicant-new.component.html',
  styleUrls: ['./applicant-new.component.css']
})
export class ApplicantNewComponent implements OnInit {

  constructor(private aps:ApplicantService) { }
  appl:Applicant=new Applicant();
  applarray:Applicant[]=[];

  ngOnInit(): void {
  }

  show()
  {
    this.aps.fetch().subscribe(
  (data:Applicant)=>
  {this.appl=data;
  
  }
  );
  
  console.log("hi from show")
  }
  
  showall()
  {
    this.aps.fetchall().subscribe(
  (data:Applicant[])=>
  {this.applarray=data;}
  
    );
  }
  
  

}
