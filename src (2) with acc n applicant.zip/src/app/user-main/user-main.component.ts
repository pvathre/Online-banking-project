import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-user-main',
  templateUrl: './user-main.component.html',
  styleUrls: ['./user-main.component.css']
})
export class UserMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

 
  month  :string=' March 2022';
   chartOptions = {   
      series : [{
         type: 'pie' as any,
         name: 'Analysis for '+this.month,
         data: [
            ['Debits',   45.0],
            
            {
               name: 'Credits',
               y: 12.8,
               sliced: true,
               selected: true
            },
            ['Transfer',    8.5],
            ['Savings',     6.2]
         ]
      }],
      chart : {
          plotBorderWidth: null as any,
         plotShadow: false
      },
      title : {
         text: 'Spend Analysis for '+this.month   
      },
      tooltip : {
         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions : {
         pie: {
            allowPointSelect: true,
            cursor: 'pointer',
      
            dataLabels: {
               enabled: false           
            },
      
            showInLegend: true
         }
      }
     
   };
  }

