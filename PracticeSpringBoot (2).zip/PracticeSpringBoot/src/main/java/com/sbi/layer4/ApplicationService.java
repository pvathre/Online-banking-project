package com.sbi.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;

@Service
public interface ApplicationService {

	public void createAppSer(Applicant a);
	public List<Applicant> getAll();
	public void getApp(int no);
	public void updAppSer(Applicant a);
	public void rem(int no);
}
