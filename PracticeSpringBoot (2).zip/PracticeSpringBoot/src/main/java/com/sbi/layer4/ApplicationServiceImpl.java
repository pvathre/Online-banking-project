package com.sbi.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;
import com.sbi.layer3.ApplicantRepository;
import com.sbi.layer3.ApplicantRepositoryImpl;

@Service
public class ApplicationServiceImpl implements ApplicationService {
@Autowired
	ApplicantRepository ap;
	
	@Override
	public void createAppSer(Applicant a) {
		// TODO Auto-generated method stub
ap.createApp(a); 
System.out.println("applicant created.."); 		

	}

	@Override
	public List<Applicant> getAll() {
		// TODO Auto-generated method stub
		return ap.findAllApp();
	}

	@Override
	public void getApp(int no) {
		// TODO Auto-generated method stub
		ap.findApp(no);	
	}

	@Override
	public void updAppSer(Applicant a) {
		// TODO Auto-generated method stub
		ap.modifyApp(a);
	}

	@Override
	public void rem(int no) {
		// TODO Auto-generated method stub
		ap.removeApp(no);
	}

	
	
}
