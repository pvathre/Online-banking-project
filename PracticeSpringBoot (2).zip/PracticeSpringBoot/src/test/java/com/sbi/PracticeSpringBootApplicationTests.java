package com.sbi;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.layer2.Account;
import com.sbi.layer3.AccountRepository;


@SpringBootTest
class PracticeSpringBootApplicationTests {
@Autowired
AccountRepository appRepo;
	
	@Test
	void contextLoads() {
		
		
	}

	@Test
	void getAccount()
	{
	
	List<Account> all = appRepo.findAllAccounts();
	System.out.println("all applicant size "+all.size());
	for (Account acc : all)
	{
		System.out.println("Account num        : "+acc.getAccountNumber());
		System.out.println("name     :  "+acc.getAccountHolderName());
		System.out.println("name     :  "+acc.getAccountBalnce());
		
	}
	

}

}
